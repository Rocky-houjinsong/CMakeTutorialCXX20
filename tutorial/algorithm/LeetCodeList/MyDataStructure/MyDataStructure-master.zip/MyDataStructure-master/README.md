# Data-Structure
考虑到很多同学的学习需要，故编写并上传此《数据结构》-严蔚敏.吴伟民-教材源码。

## 注意事项
1. **仅限个人学习使用**
2. **别抄作业**
3. **若有纰漏，望不吝指教**

## 使用说明
关于源码如何运行以及其他一些注意事项，请参考博文：[《数据结构-C语言版》（严蔚敏,吴伟民版）课本源码+习题集解析使用说明](https://www.cnblogs.com/kangjianwei101/p/5221816.html) 


## 附：源码目录
![《数据结构》源码目录](https://github.com/kangjianwei/Data-Structure/blob/master/%E7%9B%AE%E5%BD%95.png) 
