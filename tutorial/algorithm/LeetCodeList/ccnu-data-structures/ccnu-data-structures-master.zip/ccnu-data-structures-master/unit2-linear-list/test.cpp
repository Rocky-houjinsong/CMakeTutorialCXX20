#include <iostream>
//#include "linkedListWithHeadNodeFunctionHub.h"
#include "linkedListWithoutHeadNodeFunctionHub.h"

int main() {
//    LinkList LA;
//    LinkedListCreatTailInsert(LA);
//    ListTraverse(LA);
//    LinkList le;

//    GetElem(LA, 8, e);
//    GetElemNode(LA, 1, le);
//    ListTraverse(le);

//    cout << LocateElem(LA, 4);

//    ElemType pre_e;
//    cout <<  PriorElem(LA, 4, pre_e);

//    LinkList lpre;
//    PriorElemNode(LA, 4, lpre);
//    ListTraverse(lpre);

//    ElemType next_e;
//    cout << NextElem(LA, 4, next_e);

//    ListInsert(LA, 1, 114514);
//    ListTraverse(LA);

//    ElemType e;
//    ListTraverse(LA);
//    ListDelete(LA, 1, e);
//    ListTraverse(LA);


    LinkList LB, LC;
//    LinkedListCreatHeadInsert1(LB);
//    ListTraverse(LB);
//    LinkedListCreatHeadInsert2(LC);
//    ListTraverse(LC);
    LinkedListCreatTailInsert(LB);
    ListTraverse(LB);
//    DestroyList(LB);
//    printf("%p", LB);

//    ClearList(LB);
//    ListTraverse(LB);
//    cout << ListEmpty(LB);
//    cout << ListLength(LB);

//    ElemType e;
//    GetElem(LB, 3, e);
//    cout << e;

//    LinkList tnode;
//    GetElemNode(LB, 7, tnode);
//    ListTraverse(tnode);

//    cout << LocateElem(LB, 4);

//    ElemType pre_e;
//    cout << PriorElem(LB, 2, pre_e);

//    LinkList lpre_e;
//    PriorElemNode(LB, 2, lpre_e);
//    ListTraverse(lpre_e);

//    ElemType next_e;
//    cout << NextElem(LB, 3, next_e);

//    ListInsert(LB, 2, 114514);
//    ListTraverse(LB);
//    ListInsert(LB, 1, 114514);
//    ListTraverse(LB);

//    ElemType e;
//    ListDelete(LB, 1, e);
//    ListTraverse(LB);
//    ListDelete(LB, 3, e);
//    ListTraverse(LB);

    return 0;
}