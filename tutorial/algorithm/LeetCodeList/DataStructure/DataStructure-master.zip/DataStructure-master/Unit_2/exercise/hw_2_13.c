/**
 * 2.13 试写一算法在带头结点的单链表结构上实现线性表操作LOCATE(L,X)。
 */
//答案见../src/LinkList.c中的LocateElem_L(LinkList L,ElemType e,Bool (*compare)(ElemType a,ElemType b))函数。
//实参为(L,x,equals)
