/**
 * 2.14 试写一算法在带头结点的单链表结构上实现线性表操作LENGTH(L,X)。
 */
//答案见../src/LinkList.c中的ListLength_L(LinkList L)函数
