/*************************************************************************
	> File Name: check55.c
	> Author: RunRui_Li
	> Mail: 770486267@qq.com 
	> Created Time: Tue 19 Nov 2019 11:17:46 PM CST
 ************************************************************************/

#include "stdio.h"
int main(int argc,char **argv){

	int x;float y;
	scanf("%2d%f",&x,&y);
	printf("\nx=%d y=%f\n",x,y);

	return 0;
}
