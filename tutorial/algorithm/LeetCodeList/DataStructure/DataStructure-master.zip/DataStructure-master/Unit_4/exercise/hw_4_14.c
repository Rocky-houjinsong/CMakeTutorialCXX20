/**
 * 4.14 利用串的基本操作以及栈和集合的基本操作，编写“由一个算术表达式的前缀式求后缀式”的递推算法（假设前缀式不含语法错误）。
 * //与习题3.23一样，关于前缀中缀后缀的转换等写了二叉树再回来写
 */
/**
#include "StringType.c"
#include "../../Unit_3/src/SqStack.c"

int main(int argc,char **argv){

    return 0;
}

*//
