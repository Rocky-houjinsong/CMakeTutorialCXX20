/**
 * 4.16 编写算法，实现串的基本操作StrCompare(S, T)。
 */
//  见 ../src/mySString.c中的StrCompare(S,T)函数
