/**
 * 4.17 编写算法，实现串的基本操作Replace(&S,T,V)。
 */
// 见 ../src/mySString.c 中的Replace()函数
