/**
 * 4.15 编写算法，实现串的基本操作StrAssign(&T, chars)。
 */
//  见 ../src/mySString.c中的StrAssign()函数
