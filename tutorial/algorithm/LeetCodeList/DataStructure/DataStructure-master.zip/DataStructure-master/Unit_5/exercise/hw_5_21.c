/*************************************************************************
	> File Name: hw_5_21.c
	> Author: RunRui_Li
	> Mail: 770486267@qq.com 
	> Created Time: Sun 27 May 2018 08:30:35 PM CST
 ************************************************************************/

/**
 * 5.21 假设稀疏矩阵A和B均以三元组顺序表作为存储结构。试写出矩阵相加的算法，另设三元组表C存放结果矩阵。
 */

//见 ../src/TSpareMatrix.c中的AddTSMatrix(TSMtrix M,TSMtarix N,TSMatrix *Q);
