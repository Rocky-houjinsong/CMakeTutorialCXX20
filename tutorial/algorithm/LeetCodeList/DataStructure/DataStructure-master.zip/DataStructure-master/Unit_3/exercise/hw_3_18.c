/**
 * 3.18 试写一个判别表达式中开、闭括号是否配对出现的算法
 */
//答案见 ../src/checkExpression.c 中checkExpression()函数
