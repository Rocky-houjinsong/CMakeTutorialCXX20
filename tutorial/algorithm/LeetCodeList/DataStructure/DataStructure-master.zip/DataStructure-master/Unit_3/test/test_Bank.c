
#include "../src/Bank_Simulation.c"

int main(int argc,char **args){
	Bank_Simulation(100);
}
