/**
 */
#include "../src/Expression.c"

int main(int argc,char **args){
	printf(" = %.2f\n",Expression());	
}
