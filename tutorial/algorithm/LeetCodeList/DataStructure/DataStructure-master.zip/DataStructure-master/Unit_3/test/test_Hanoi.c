#include "../src/Hanoi.c"

int main(int argc,char **args){
	hanoi(64,'a','b','c');
	return 0;
}
