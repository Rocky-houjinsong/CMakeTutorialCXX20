#include "../src/lineEdit.c"

int main(int argc,char **args){
	lineEdit();
	return 0;
}
