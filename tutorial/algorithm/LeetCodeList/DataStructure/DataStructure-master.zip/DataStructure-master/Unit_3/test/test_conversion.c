#include "../src/conversion.c"

void main(){
	conversion();
}
